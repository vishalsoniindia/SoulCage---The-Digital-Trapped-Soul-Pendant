## 🔧 Steps to Upload Code

1. Open the folder and **double-click** "esp32_upload.bat".
2. If Windows shows *"Windows Protected your PC"*, click:
   - **More Info**
   - **Run Anyway**
3. From the COM port list, **select the list number (Not COM NUMBER)** where your ESP32 is connected.
4. Press **Enter** to continue.
5. Wait until you see:  
   ✅ **"Flash Complete"** at the end.
6. Press **any key** if you want to program another device.

---